package br.csi.dao;

import br.csi.model.Usuario;
import br.csi.util.ConectaDBPostgres;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class UsuarioDAO {

    public ArrayList getUsuarios(){
        try {
            Statement stmt = new ConectaDBPostgres ().getConexao().createStatement();
            ResultSet ans = stmt.executeQuery("SELECT * FROM usuario");

            ArrayList users = new ArrayList<>();

            while (ans.next()) {
                users.add(new Usuario(ans.getInt("id"),
                        ans.getString("nome"),
                        ans.getString("email"),
                        ans.getString("senha"),
                        ans.getDate("datacadastro"),
                        ans.getBoolean("ativo")));

            }
            return users;
        }catch (java.sql.SQLException e){
            e.printStackTrace();
            return null;
        }
    }
}

